import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-room-booking',
  templateUrl: './room-booking.component.html',
  styleUrls: ['./room-booking.component.css']
})
export class RoomBookingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  
}
